<!--
appendix_id: APP-A
title: Python, NumPy e PyTorch essenziali
status: candidatura completa in revisione autoriale
version: 0.2.0-rc1
last_source_check: 2026-07-31
-->

# Appendice A. Python, NumPy e PyTorch essenziali

Fornire un riferimento operativo minimo per leggere ed eseguire gli snippet del libro.

## Ambiente e moduli

Usare un ambiente isolato, registrare la versione di Python e installare dipendenze con vincoli espliciti. `python -m venv .venv` crea un ambiente, mentre `python -m pip freeze` fotografa i pacchetti installati. Il file di lock non sostituisce il sistema operativo e il driver, ma rende visibili le dipendenze Python.

## Tipi e collezioni

Liste, tuple, dizionari e dataclass descrivono configurazioni e record. Una tuple comunica immutabilità intenzionale; un dizionario collega chiavi e valori; una dataclass rende espliciti i campi. Le type annotation aiutano strumenti e review, ma non impongono da sole controlli a runtime.

## NumPy

Un array NumPy possiede dtype, shape, stride e memoria. Broadcasting e vectorization permettono di esprimere operazioni senza loop Python. `reshape` cambia la vista quando possibile, mentre `copy` alloca dati indipendenti. Controllare sempre l'asse su cui avviene una riduzione.

![Dal dato Python al parametro aggiornato](../../assets/appendices/A_python_numpy_pytorch/APP-A-01/candidate-v1.png)

I livelli di astrazione condividono valori, ma aggiungono contratti. Dtype, shape, device e modalità devono restare visibili in ogni passaggio.

## Tensor PyTorch

Un tensor PyTorch aggiunge device e integrazione con autograd. `torch.tensor` copia i dati; `torch.from_numpy` può condividere memoria con NumPy. Dtype, device e `requires_grad` devono essere dichiarati quando cambiano il contratto.

## Moduli e parametri

`nn.Module` registra sotto-moduli e parametri. `state_dict()` restituisce tensori nominati; `train()` e `eval()` cambiano il comportamento dei moduli sensibili alla modalità. L'optimizer aggiorna soltanto i parametri che riceve.

## Autograd e inference

`loss.backward()` accumula gradienti nei leaf tensor. `zero_grad(set_to_none=True)` separa gli update. `torch.no_grad()` e `torch.inference_mode()` disabilitano il tracciamento con contratti differenti; non sostituiscono `model.eval()`.

## Esempio minimo

```python
import torch
from torch import nn

x = torch.tensor([[1.0, 2.0]], dtype=torch.float32)
model = nn.Linear(2, 1)
optimizer = torch.optim.SGD(model.parameters(), lr=0.1)

optimizer.zero_grad(set_to_none=True)
loss = (model(x) - torch.tensor([[1.0]])).pow(2).mean()
loss.backward()
optimizer.step()
```

## Fonti e aggiornamento

Le fonti principali e le versioni sono registrate in [`SOURCES.md`](SOURCES.md). L'appendice viene aggiornata quando cambiano API, standard, formule o riferimenti dell'opera.
