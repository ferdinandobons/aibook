# Fonti. Appendice A

- Ultima verifica: 31 luglio 2026

## `SRC-APP-A-001`

Python documentation.

URL: https://docs.python.org/3/

## `SRC-APP-A-002`

NumPy documentation.

URL: https://numpy.org/doc/stable/

## `SRC-APP-A-003`

PyTorch documentation.

URL: https://pytorch.org/docs/stable/

