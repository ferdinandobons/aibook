<!--
appendix_id: APP-C
title: Formulario matematico
status: candidatura completa in revisione autoriale
version: 0.2.0-rc1
last_source_check: 2026-07-31
-->

# Appendice C. Formulario matematico

Raccogliere formule ricorrenti senza sostituire le derivazioni dei capitoli.

## Algebra lineare

Prodotto scalare: $x^Ty$. Trasformazione affine: $y=Wx+b$. Norma L2: $\|x\|_2=\sqrt{\sum_i x_i^2}$. SVD: $X=U\Sigma V^T$.

## Calcolo

Regola della catena: $\frac{dL}{dx}=\frac{dL}{dy}\frac{dy}{dx}$. Gradiente: $\nabla_\theta L$. Jacobiana: $J_{ij}=\partial f_i/\partial x_j$.

## Probabilità

Bayes: $p(h|e)=p(e|h)p(h)/p(e)$. Valore atteso: $\mathbb E[X]$. Varianza: $\mathbb E[(X-\mathbb E[X])^2]$.

![Mappa delle formule](../../assets/appendices/C_formulario_matematico/APP-C-01/candidate-v1.png)

Le formule sono raggruppate per funzione, non per ordine storico. Ogni formula richiede simboli, dominio e condizioni definiti nel capitolo proprietario.

## Informazione

Entropia: $H(p)=-\sum p\log p$. Cross-entropy: $H(q,p)=-\sum q\log p$. KL: $D_{KL}(q\|p)=\sum q\log(q/p)$.

## Ottimizzazione

SGD: $\theta_{t+1}=\theta_t-\eta g_t$. Momentum e Adam aggiungono stime mobili. Weight decay decoupled modifica i pesi separatamente dall'update adattivo.

## Attention

$\operatorname{softmax}(QK^T/\sqrt{d_k})V$. Cache KV di base: $2BLNh_{kv}d_hs$ byte. RoPE applica rotazioni a coppie di coordinate.

## Generazione

Autoregressione: $p(x)=\prod_t p(x_t|x_{<t})$. ELBO: $\mathbb E_q[\log p(x|z)]-D_{KL}(q(z|x)\|p(z))$. Diffusion e flow matching definiscono obiettivi diversi.

## Fonti e aggiornamento

Le fonti principali e le versioni sono registrate in [`SOURCES.md`](SOURCES.md). L'appendice viene aggiornata quando cambiano API, standard, formule o riferimenti dell'opera.
