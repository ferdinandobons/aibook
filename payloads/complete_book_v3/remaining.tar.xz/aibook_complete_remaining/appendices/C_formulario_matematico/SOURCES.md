# Fonti. Appendice C

- Ultima verifica: 31 luglio 2026

## `SRC-APP-C-001`

Deep Learning book.

URL: https://www.deeplearningbook.org/

## `SRC-APP-C-002`

Murphy, Probabilistic Machine Learning.

URL: https://probml.github.io/pml-book/

