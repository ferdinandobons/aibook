<!--
appendix_id: APP-B
title: JAX, compilazione e trasformazioni funzionali
status: candidatura completa in revisione autoriale
version: 0.2.0-rc1
last_source_check: 2026-07-31
-->

# Appendice B. JAX, compilazione e trasformazioni funzionali

Offrire un ponte verso il paradigma funzionale e la compilazione di programmi numerici.

## Funzioni pure e PyTree

JAX tratta i parametri come dati espliciti e organizza strutture annidate in PyTree. Una funzione pura restituisce il nuovo stato invece di modificare oggetti nascosti. Questa disciplina facilita trasformazioni e distribuzione.

## Array e immutabilità

`jax.numpy` segue gran parte dell'API NumPy, ma gli array sono concettualmente immutabili. Aggiornamenti funzionali usano `.at[index].set(...)`. Il comportamento asincrono richiede sincronizzazione nei benchmark.

## grad, value_and_grad

`jax.grad` trasforma una funzione scalare in una funzione che calcola gradienti. `value_and_grad` restituisce valore e gradiente nello stesso contratto. Gli argomenti differenziati devono essere floating o compatibili.

![Trasformazioni di una funzione numerica](../../assets/appendices/B_jax_compilation/APP-B-01/candidate-v1.png)

La stessa funzione può essere differenziata, vectorizzata e compilata. Ogni trasformazione conserva una semantica dichiarata e aggiunge vincoli su shape e stato.

## jit

`jax.jit` traccia la funzione per shape e valori statici e compila il programma con XLA. Il primo run include compilazione; i successivi possono riusare l'eseguibile. Controllo di flusso Python dipendente da dati richiede primitive JAX.

## vmap e pmap

`vmap` vectorizza una funzione su un asse. `pmap` esegue una forma SPMD su dispositivi, mentre API più recenti usano sharding esplicito. La semantica della riduzione deve essere dichiarata.

## Randomness

Le chiavi PRNG sono esplicite e vengono splittate. Riutilizzare la stessa chiave ripete il campione. La riproducibilità resta condizionata a versione, hardware e algoritmi.

## Esempio

```python
import jax
import jax.numpy as jnp

def loss(w, x, y):
    prediction = x @ w
    return jnp.mean((prediction - y) ** 2)

value, gradient = jax.value_and_grad(loss)(jnp.zeros(2), x, y)
compiled = jax.jit(jax.value_and_grad(loss))
```

## Fonti e aggiornamento

Le fonti principali e le versioni sono registrate in [`SOURCES.md`](SOURCES.md). L'appendice viene aggiornata quando cambiano API, standard, formule o riferimenti dell'opera.
