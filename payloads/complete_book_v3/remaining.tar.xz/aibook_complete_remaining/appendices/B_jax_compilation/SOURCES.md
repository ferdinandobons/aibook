# Fonti. Appendice B

- Ultima verifica: 31 luglio 2026

## `SRC-APP-B-001`

JAX documentation.

URL: https://docs.jax.dev/

## `SRC-APP-B-002`

OpenXLA documentation.

URL: https://openxla.org/

## `SRC-APP-B-003`

JAX transformations.

URL: https://docs.jax.dev/en/latest/key-concepts.html

