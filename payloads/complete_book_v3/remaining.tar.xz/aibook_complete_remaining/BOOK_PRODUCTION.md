# Piano operativo per la produzione completa del libro

## Milestone raggiunta

- Capitoli: 98 su 98 prodotti
- Appendici: 12 su 12 prodotte
- Branch: `feature/full-book-production`
- PR: `#2`, draft
- Data: 31 luglio 2026

## Stato

La fase di produzione seriale è conclusa. L'opera entra nella fase di revisione autoriale trasversale. Nessun capitolo viene dichiarato congelato prima dell'approvazione.

## Processo di revisione finale

```text
lettura autoriale per parte
-> correzioni tecniche e linguistiche
-> nuova esecuzione dei test coinvolti
-> rigenerazione delle visuali modificate
-> audit completo dei riferimenti
-> promozione delle candidate approvate
-> congelamento
-> merge in main
```

## Verifica trasversale

Il validator controlla presenza degli artefatti, test, immagini, sfondo bianco, riferimenti e appendici. L'audit di continuità è in `docs/06_CONTINUITA_TRA_CAPITOLI.md`.

## Regola temporale

Una fonte o API che può essere cambiata dopo il 31 luglio 2026 viene riaperta prima del congelamento.
