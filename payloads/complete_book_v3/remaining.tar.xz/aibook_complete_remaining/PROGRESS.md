# Avanzamento del libro

## Stato corrente

- Repository: `ferdinandobons/aibook`
- Branch di produzione: `feature/full-book-production`
- Pull request: `#2`, draft
- Opera pianificata: 98 capitoli e 12 appendici
- Capitoli prodotti: **98 su 98**
- Appendici prodotte: **12 su 12**
- Ultima ricerca globale: 30 luglio 2026
- Ultima verifica delle fonti del blocco finale: 31 luglio 2026
- Stato editoriale: candidature complete in revisione autoriale
- Congelamento: non ancora eseguito

## Parti

| Parte | Intervallo | Stato |
|---|---:|---|
| P01 | 1-4 | prodotta |
| P02 | 5-9 | prodotta |
| P03 | 10-14 | prodotta |
| P04 | 15-19 | prodotta |
| P05 | 20-25 | prodotta |
| P06 | 26-31 | prodotta |
| P07 | 32-36 | prodotta |
| P08 | 37-45 | prodotta |
| P09 | 46-54 | prodotta |
| P10 | 55-62 | prodotta |
| P11 | 63-72 | prodotta |
| P12 | 73-82 | prodotta |
| P13 | 83-93 | prodotta |
| P14 | 94-98 | prodotta |

## Gate completati internamente

- fonti e claim;
- prosa e continuità;
- formule e codice;
- test automatici;
- visuali candidate e audit;
- review tecnica, didattica e linguistica;
- verifica per lettore non esperto.

## Gate ancora aperti

- revisione autoriale delle candidature;
- promozione delle immagini da `candidate-v1.png` a `final.png`;
- eventuali correzioni dopo la lettura completa dell'autore;
- congelamento e merge in `main`.

## Confine temporale

Il libro non dichiara aggiornamento oltre il 31 luglio 2026. Norme, API, standard, prodotti e tecniche FRONTIER devono essere ricontrollati prima del congelamento o di una nuova edizione.
